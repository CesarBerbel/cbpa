from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("accounts.urls")),
    path("", include("companies.urls")),
    path("", include("dashboard.urls")),
    path("", include("finances.urls")),
]
